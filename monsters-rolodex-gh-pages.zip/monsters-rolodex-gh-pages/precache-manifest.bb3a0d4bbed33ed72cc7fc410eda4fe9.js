self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b615c05f37db378c21b9cda77d884beb",
    "url": "/monsters-rolodex/index.html"
  },
  {
    "revision": "50579abe86663319cb41",
    "url": "/monsters-rolodex/static/css/main.fedab3a4.chunk.css"
  },
  {
    "revision": "88b685495fee72b0273c",
    "url": "/monsters-rolodex/static/js/2.2eaf0afe.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/monsters-rolodex/static/js/2.2eaf0afe.chunk.js.LICENSE.txt"
  },
  {
    "revision": "50579abe86663319cb41",
    "url": "/monsters-rolodex/static/js/main.d24c7cdc.chunk.js"
  },
  {
    "revision": "9b59177dc23ec2a3d1f7",
    "url": "/monsters-rolodex/static/js/runtime-main.fa9629a0.js"
  }
]);